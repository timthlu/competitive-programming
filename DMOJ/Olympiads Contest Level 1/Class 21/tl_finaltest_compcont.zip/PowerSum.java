import java.util.Scanner;
//finished user input, stuck on what to do for solution
public class PowerSum {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int x = scanner.nextInt();
		int n = scanner.nextInt();
		
		for (int i = Math.floor(Math.pow(x, -n)); i > 1; i--) {
			
		}
	}
}